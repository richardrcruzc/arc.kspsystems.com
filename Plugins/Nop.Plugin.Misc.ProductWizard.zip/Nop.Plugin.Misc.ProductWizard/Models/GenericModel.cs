﻿
using Nop.Web.Framework.Mvc.Models;

namespace Nop.Plugin.Misc.ProductWizard.Models
{
    public class GenericModel: BaseNopEntityModel
    { 
        public bool ExcludeGoogleFeed { get; set; }
        public string Color { get; set; }
    }
}
